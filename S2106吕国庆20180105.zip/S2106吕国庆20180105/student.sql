INSERT INTO `student` (`StudentNo`, `LoginPwd`, `StudentName`, `Sex`, `Phone`, `Address`, `BornDate`) VALUES ('10001', '123', '郭亚斌', '男', '1237282732', '', NULL);
INSERT INTO `student` (`StudentNo`, `LoginPwd`, `StudentName`, `Sex`, `Phone`, `Address`, `BornDate`) VALUES ('10002', '123', '小明', '男', '21314213123', '', NULL);
INSERT INTO `student` (`StudentNo`, `LoginPwd`, `StudentName`, `Sex`, `Phone`, `Address`, `BornDate`) VALUES ('10003', '123', '小红', '女', '1231232141423', NULL, NULL);
