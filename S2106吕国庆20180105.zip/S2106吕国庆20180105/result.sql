INSERT INTO `result` (`id`, `studentNo`, `score`, `ExamDate`) VALUES (1, '10001', 53, '2018-1-3');
INSERT INTO `result` (`id`, `studentNo`, `score`, `ExamDate`) VALUES (2, '10002', 67, '2018-1-3');
INSERT INTO `result` (`id`, `studentNo`, `score`, `ExamDate`) VALUES (3, '10003', 84, '2018-1-3');
