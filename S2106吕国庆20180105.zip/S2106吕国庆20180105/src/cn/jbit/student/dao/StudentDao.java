package cn.jbit.student.dao;
import java.util.List;

import cn.jbit.student.entity.*;
public interface StudentDao {
	List<Student> print();

}
